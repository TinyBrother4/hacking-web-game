// Elements
const terminal = document.getElementById('terminal');
const commandInput = document.getElementById('command');
const loginScreen = document.getElementById('login-screen');
const terminalScreen = document.getElementById('terminal-screen');
const loginEmail = document.getElementById('login-email');
const loginPassword = document.getElementById('login-password');
const loginBtn = document.getElementById('login-btn');
const loginMsg = document.getElementById('login-msg');

// Utilities
function print(text, cls = "output") {
  const div = document.createElement('div');
  div.className = cls;
  div.textContent = text;
  terminal.appendChild(div);
  terminal.scrollTop = terminal.scrollHeight;
}

function banner() {
  print("Welcome to SimNet — a local terminal game.", "output system");
  print("⚠️ This is a game: no real network access.", "output warn");
  print("💡 Type 'help' to see all available commands.", "output system");
}

// Fake network state
let connected = null;
let targets = [];
let compromisedCount = 0;

// Generate fake targets
function generateTargets() {
  const names = ["ARC-Node", "Nimbus", "Helix", "Pulse", "Vector", "Quasar", "Aether", "Ion", "Nova", "Cipher"];
  const servicesPool = ["http", "ssh", "db", "cache", "mq", "files", "dns"];
  const out = [];
  for (let i = 0; i < 8; i++) {
    const level = Math.ceil(Math.random() * 5);
    const services = shuffle(servicesPool).slice(0, 3 + Math.floor(Math.random() * 3));
    out.push({
      id: `H${String(i + 1).padStart(2, "0")}`,
      name: names[i % names.length] + "-" + (100 + Math.floor(Math.random() * 900)),
      ip: `10.${Math.floor(Math.random() * 200) + 10}.${Math.floor(Math.random() * 200) + 10}.${Math.floor(Math.random() * 200) + 10}`,
      level,
      services,
      probed: false,
      compromised: false,
      loot: [],
      traceRisk: 0
    });
  }
  return out;
}

function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function listTargets() {
  print("Discovered hosts:", "output system");
  targets.forEach(t => {
    print(`[${t.id}] ${t.name} (${t.ip}) lvl:${t.level} ${t.compromised ? "[ACCESS]" : ""}`, "output id");
  });
}

function connectTarget(id) {
  const t = targets.find(x => x.id === id);
  if (!t) return print("No such host. Use 'targets' to list IDs.", "output error");
  connected = t.id;
  print(`Connection established with [${t.id}] ${t.name} (${t.ip})`, "output success");
}

function status() {
  if (!connected) return print("Not connected. Use 'connect <id>'.", "output warn");
  const t = targets.find(x => x.id === connected);
  print(`Target [${t.id}] ${t.name} (${t.ip})`, "output system");
  print(`Security level: ${t.level}`, "output system");
  print(`Services: ${t.services.join(", ")}`, "output system");
  print(`Probed: ${t.probed ? "yes" : "no"} | Access: ${t.compromised ? "granted" : "none"} | Trace risk: ${t.traceRisk}%`, "output system");
}

function probe() {
  if (!connected) return print("Not connected. Use 'connect <id>'.", "output warn");
  const t = targets.find(x => x.id === connected);
  t.probed = true;
  t.traceRisk = Math.min(100, t.traceRisk + 10 + Math.floor(Math.random() * 10));
  print(`Probing [${t.id}]... Services detected: ${t.services.join(", ")}. Trace risk ${t.traceRisk}%.`, "output system");
}

function crack() {
  if (!connected) return print("Not connected. Use 'connect <id>'.", "output warn");
  const t = targets.find(x => x.id === connected);
  if (t.compromised) return print("Already accessed.", "output warn");

  const base = t.probed ? 60 : 30;
  const chance = Math.max(5, base - t.level * 8);
  const roll = Math.floor(Math.random() * 100);

  if (roll < chance) {
    t.compromised = true;
    compromisedCount++;
    t.loot = generateLoot(t);
    print(`Access granted on [${t.id}] ${t.name}.`, "output success");
  } else {
    t.traceRisk = Math.min(100, t.traceRisk + 15);
    print(`Access attempt failed on [${t.id}]. Trace risk now ${t.traceRisk}%.`, "output error");
  }
}

function generateLoot(t) {
  const items = ["logs", "configs", "blueprints", "keys", "reports", "snapshots", "metrics", "archives"];
  const count = 2 + Math.floor(Math.random() * 3);
  return shuffle(items).slice(0, count).map(x => `${x}@${t.name}`);
}

function loot() {
  if (!connected) return print("Not connected. Use 'connect <id>'.", "output warn");
  const t = targets.find(x => x.id === connected);
  if (!t.compromised) return print("No access yet. Use 'crack'.", "output warn");
  print(`Loot from [${t.id}]:`, "output system");
  t.loot.forEach(item => print("- " + item));
}

function disconnect() {
  if (!connected) return print("No active session.", "output warn");
  const t = targets.find(x => x.id === connected);
  print(`Disconnected from [${t.id}] ${t.name}.`, "output system");
  connected = null;
}

function resetState() {
  connected = null;
  compromisedCount = 0;
  targets = generateTargets();
  print("Network reset: new hosts discovered.", "output system");
}
// Desktop menu
function desktop() {
  if (!connected) return print("Not connected. Use 'connect <id>'.", "output warn");
  const t = targets.find(x => x.id === connected);
  if (!t.compromised) return print("No access yet. Use 'crack' first.", "output warn");

  print(`--- Desktop Menu for [${t.id}] ${t.name} ---`, "output system");
  print("1. 📂 Files", "output system");
  print("2. 🔑 Credentials", "output system");
  print("3. 🖥️ System Info", "output system");
  print("4. 🏦 Bank Access", "output system");
  print("----------------------------------------", "output system");
  print("Type 'files', 'creds', 'sysinfo', 'bank', or 'bankloot'.", "output system");
}

function files() {
  if (!connected) return print("Not connected.", "output warn");
  const t = targets.find(x => x.id === connected);
  if (!t.compromised) return print("No access yet. Use 'crack'.", "output warn");

  print(`Files on [${t.id}]:`, "output system");
  t.loot.forEach(item => print("- " + item));
}

function creds() {
  if (!connected) return print("Not connected.", "output warn");
  const t = targets.find(x => x.id === connected);
  if (!t.compromised) return print("No access yet. Use 'crack'.", "output warn");

  // Only generate creds once per target
  if (!t.username || !t.password) {
    t.username = t.name.toLowerCase().split("-")[0];
    t.password = "pass" + Math.floor(Math.random() * 9999);
  }

  print(`Credentials for [${t.id}]:`, "output system");
  print(`Username: ${t.username}`, "output system");
  print(`Password: ${t.password}`, "output system");
}

function sysinfo() {
  if (!connected) return print("Not connected.", "output warn");
  const t = targets.find(x => x.id === connected);
  if (!t.compromised) return print("No access yet. Use 'crack'.", "output warn");

  print(`System Info for [${t.id}]:`, "output system");
  print(`Host: ${t.name}`, "output system");
  print(`IP: ${t.ip}`, "output system");
  print(`Security Level: ${t.level}`, "output system");
  print(`Services: ${t.services.join(", ")}`, "output system");
}

// Bank feature
function bank() {
  if (!connected) return print("Not connected. Use 'connect <id>'.", "output warn");
  const t = targets.find(x => x.id === connected);
  if (!t.compromised) return print("No access yet. Use 'crack'.", "output warn");

  print(`--- Bank Access Portal for [${t.id}] ${t.name} ---`, "output system");
  print("Type: banklogin <username> <password>", "output system");
}

function banklogin(user, pass) {
  if (!connected) return print("Not connected.", "output warn");
  const t = targets.find(x => x.id === connected);
  if (!t.compromised) return print("No access yet. Use 'crack'.", "output warn");

  // Check against stored creds
  if (user === t.username && pass === t.password) {
    t.bankBalance = t.bankBalance || (1000 + Math.floor(Math.random() * 9000));
    print(`💰 Logged into ${t.name}'s bank account.`, "output success");
    print("Balance: $" + t.bankBalance, "output system");
    print("Recent transactions:", "output system");
    print("- Grocery Store: -$54.23", "output system");
    print("- Salary Deposit: +$2,300.00", "output system");
    print("- Online Purchase: -$120.99", "output system");
  } else {
    print("❌ Invalid credentials. Access denied.", "output error");
  }
}

// Special bank loot command
function bankloot() {
  if (!connected) return print("Not connected.", "output warn");
  const t = targets.find(x => x.id === connected);
  if (!t.compromised) return print("No access yet. Use 'crack'.", "output warn");

  if (!t.username || !t.password) {
    return print("No credentials found. Use 'creds' first.", "output warn");
  }

  if (!t.bankBalance) {
    return print("You must log in first with 'banklogin <user> <pass>'.", "output warn");
  }

  const stolen = t.bankBalance;
  t.bankBalance = 0;
  print(`💸 You looted $${stolen} from ${t.name}'s bank account!`, "output success");
  print("The account is now empty.", "output system");
}
// Command router
function runCommand(raw) {
  const parts = raw.trim().split(" ");
  const base = parts[0];
  const arg = parts[1];

  switch (base) {
    case "help":
      print(
        "Commands:\n" +
        "help, targets, connect <id>, status, probe, crack, loot, disconnect, reset,\n" +
        "desktop, files, creds, sysinfo, bank, banklogin <user> <pass>, bankloot,\n" +
        "setemail <email>, setpassword <password>, login, resetstore, exit",
        "output system"
      );
      break;

    // Core gameplay
    case "targets": listTargets(); break;
    case "connect": connectTarget(arg); break;
    case "status": status(); break;
    case "probe": probe(); break;
    case "crack": crack(); break;
    case "loot": loot(); break;
    case "disconnect": disconnect(); break;
    case "reset": resetState(); break;

    // Desktop menu
    case "desktop": desktop(); break;
    case "files": files(); break;
    case "creds": creds(); break;
    case "sysinfo": sysinfo(); break;

    // Bank feature
    case "bank": bank(); break;
    case "banklogin":
      if (parts.length < 3) return print("Usage: banklogin <username> <password>", "output warn");
      banklogin(parts[1], parts[2]);
      break;
    case "bankloot": bankloot(); break;

    // Credential storage
    case "setemail":
      if (!arg) return print("Usage: setemail <email>", "output warn");
      localStorage.setItem("terminalEmail", arg);
      print("✅ Email set.", "output success");
      break;

    case "setpassword":
      if (!arg) return print("Usage: setpassword <password>", "output warn");
      localStorage.setItem("terminalPassword", arg);
      print("✅ Password set.", "output success");
      break;

    case "login":
      const savedEmail = localStorage.getItem("terminalEmail");
      const savedPassword = localStorage.getItem("terminalPassword");
      if (!savedEmail && !savedPassword) {
        return print("No credentials set. Use setemail/setpassword.", "output warn");
      }
      terminalScreen.style.display = "none";
      loginScreen.style.display = "block";
      break;

    case "resetstore":
      localStorage.clear();
      print("🧹 Local storage cleared. Credentials removed.", "output system");
      break;

    // Exit
    case "exit":
      print("Session closed.", "output system");
      commandInput.disabled = true;
      break;

    // Unknown
    default:
      if (raw.trim() !== "") print("Unknown command: " + raw, "output error");
  }
}

// Input handler
commandInput.addEventListener("keydown", e => {
  if (e.key === "Enter") {
    const cmd = commandInput.value;
    print("$ " + cmd);
    runCommand(cmd);
    commandInput.value = "";
  }
});

// Initialize
targets = generateTargets();
banner();

// Login button behavior
loginBtn?.addEventListener("click", () => {
  const savedEmail = localStorage.getItem("terminalEmail") || "";
  const savedPassword = localStorage.getItem("terminalPassword") || "";
  if (!savedEmail && !savedPassword) {
    loginMsg.textContent = "No credentials set. Use setemail/setpassword in the terminal.";
    return;
  }
  if (loginEmail.value === savedEmail && loginPassword.value === savedPassword) {
    loginMsg.textContent = "Login successful.";
    loginScreen.style.display = "none";
    terminalScreen.style.display = "flex";
    print("✅ Login successful. Welcome to SimNet.", "output success");
  } else {
    loginMsg.textContent = "Invalid email or password.";
  }
});
